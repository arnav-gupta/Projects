#include<arpa/inet.h> 
#include<net/ethernet.h>
#include<netinet/ip_icmp.h>   
#include<netinet/udp.h>   
#include<netinet/tcp.h>   
#include<netinet/ip.h>    
#include<pcap.h>
#include<stdio.h>
#include<stdlib.h> 
#include<string.h> 
#include <unistd.h>
#include <ctype.h>
#include<sys/socket.h>
void process_packet(u_char *, const struct pcap_pkthdr *, const u_char *);
void ip_resolve(const u_char * , int);
void ip_print(const u_char * , int);
void tcp_print(const u_char *  , int );
void udp_print(const u_char * , int);
void icmp_print(const u_char * , int );
void data_print (const u_char * , int);
int tcp=0,udp=0,icmp=0,others=0,igmp=0,total=0,i,j;  
FILE *logfile;
struct sockaddr_in source,dest;

 char *svalue = NULL;
int main(int argc, char **argv)
{
    pcap_t *handle; 
    int count = 1 , n;
char *temp_exp1 =" ", *temp_exp2, *temp_exp3;
char filter_exp [80] ;
	char *dev = NULL;
	char errbuf[PCAP_ERRBUF_SIZE];
	struct bpf_program filter;		
	bpf_u_int32 mask;		
	bpf_u_int32 net;		
	char *rvalue = NULL;
	char *ivalue = NULL;
  	int index;
  	int c;
	int fll =0;
	 opterr = 0;
	 while ((c = getopt (argc, argv, "i:r:s:")) != -1)
    switch (c)
      {
      case 'i':
        ivalue = optarg;
        break;
      case 'r':
	   rvalue = optarg;
        break;
      case 's':
        svalue = optarg;
        break;
      case '?':
        if (optopt == 'c')
          fprintf (stderr, "Option -%c requires an argument.\n", optopt);
        else if (isprint (optopt))
          fprintf (stderr, "Unknown option `-%c'.\n", optopt);
        else
          fprintf (stderr,
                   "Unknown option character `\\x%x'.\n",
                   optopt);
      default:
        abort ();
      }
//	printf("Filter expression: %s\n", argv [optind]);
	if(	argv [optind] != NULL) {
	fll =100;
	temp_exp2 = argv [optind];
	temp_exp3 = argv [++optind];
	snprintf(filter_exp, sizeof filter_exp, "%s%s%s", temp_exp2, temp_exp1, temp_exp3);
	}
//	printf("Filter expression: %s\n", filter_exp);
if(ivalue !=NULL) {
	if (ivalue !=NULL) {
		dev = ivalue;
	}
	else if (argc > 7) {
		fprintf(stderr, "error: unrecognized command-line options\n\n");
		exit(EXIT_FAILURE);
	}
	else {
		dev = pcap_lookupdev(errbuf);
		if (dev == NULL) {
			fprintf(stderr, "Couldn't find default device: %s\n",
			    errbuf);
			exit(EXIT_FAILURE);
		}
	}
	if (pcap_lookupnet(dev, &net, &mask, errbuf) == -1) {
		fprintf(stderr, "Couldn't get netmask for device %s: %s\n",dev, errbuf);
		net = 0;
		mask = 0;
	}
	printf("Device: %s\n", dev);
	//printf("Filter expression: %s\n", filter_exp);
	handle = pcap_open_live(dev, 65536, 1, 512, errbuf);
	if (handle == NULL) {
		fprintf(stderr, "Couldn't open device %s: %s\n", dev, errbuf);
}
	if (pcap_datalink(handle) != DLT_EN10MB) {
		fprintf(stderr, "%s is not an Ethernet\n", dev);
		exit(EXIT_FAILURE);
	}
	if(fll == 100){
	if (pcap_compile(handle, &filter, filter_exp, 0, net) == -1) {
		fprintf(stderr, "Couldn't parse filter %s: %s\n",
		    filter_exp, pcap_geterr(handle));
		exit(EXIT_FAILURE);
	}
	if (pcap_setfilter(handle, &filter) == -1) {
		fprintf(stderr, "Couldn't install filter %s: %s\n",
		    filter_exp, pcap_geterr(handle));
		exit(EXIT_FAILURE);
	}
}
    logfile=fopen("log.txt","w");
    if(logfile==NULL) 
    {
        printf("Unable to create file.");
    }
        printf("Output stored in log.txt file.\n");
	pcap_loop(handle, -1, process_packet, NULL);



}	
if(rvalue != NULL) {
     handle = pcap_open_offline("http_first_sample.pcap", errbuf);
//    logfile=fopen("log.txt","w");
//	printf("filter_exp  %s:\n",filter_exp);
  /*  if(logfile==NULL) 
    {
        printf("Unable to create file.");
    }*/
	if(fll == 100){
	if (pcap_compile(handle, &filter, filter_exp, 0, net) == -1) {
        printf("Bad filter - %s\n", pcap_geterr(handle));
        return 2;
    }
    if (pcap_setfilter(handle, &filter) == -1) {
        printf("Error setting filter - %s\n", pcap_geterr(handle));
        return 2;
    }     
}

    logfile=fopen("log.txt","w");
    if(logfile==NULL) 
    {
        printf("Unable to create file.");
    }
        printf("Output stored in log.txt file.\n");
	pcap_loop(handle, -1, process_packet, NULL);

}
	pcap_freecode(&filter);
	pcap_close(handle);
return 0;
}
void process_packet(u_char *args, const struct pcap_pkthdr *header, const u_char *buffer)
{
    int tot_len = header->len;
    struct iphdr *iph = (struct iphdr*)(buffer + sizeof(struct ethhdr));
    ++total;
    switch (iph->protocol) 
    {
        case 1:  
            ++icmp;
            icmp_print( buffer , tot_len);
            break;
         
        case 2:  
            ++igmp;
            break;
         
        case 6:  
            ++tcp;
            tcp_print(buffer , tot_len);
            break;
         
        case 17: 
            ++udp;
            udp_print(buffer , tot_len);
            break;
         
        default: 
            ++others;
            break;
    }
    printf("TCP : %d   UDP : %d   ICMP : %d   IGMP : %d   Others : %d   Total : %d\r", tcp , udp , icmp , igmp , others , total);
}
 void print_ethernet_header(const u_char *Buffer, int Size)
{
    struct ethhdr *eth = (struct ethhdr *)Buffer;

    fprintf(logfile , "Header- Ethernet\n");
    fprintf(logfile , "source addr      : %.2X-%.2X-%.2X-%.2X-%.2X-%.2X \n", eth->h_source[0] , eth->h_source[1] , eth->h_source[2] , eth->h_source[3] , eth->h_source[4] , eth->h_source[5] );
    fprintf(logfile , "dest addr : %.2X-%.2X-%.2X-%.2X-%.2X-%.2X \n", eth->h_dest[0] , eth->h_dest[1] , eth->h_dest[2] , eth->h_dest[3] , eth->h_dest[4] , eth->h_dest[5] );
    fprintf(logfile , "proto: %u \n",(unsigned short)eth->h_proto);
}
void print_ip_header(const u_char * Buffer, int Size)
{
    print_ethernet_header(Buffer , Size);
    unsigned short len_iph;
    struct iphdr *iph = (struct iphdr *)(Buffer  + sizeof(struct ethhdr) );
    len_iph =iph->ihl*4;
    memset(&source, 0, sizeof(source));
    source.sin_addr.s_addr = iph->saddr;
    memset(&dest, 0, sizeof(dest));
    dest.sin_addr.s_addr = iph->daddr;
    fprintf(logfile , "\n");
    fprintf(logfile , "header- IP\n");
    fprintf(logfile , "ip version: %d\n",(unsigned int)iph->version);
    fprintf(logfile , "IP header len: %d DWORDS or %d Bytes\n",(unsigned int)iph->ihl,((unsigned int)(iph->ihl))*4);
    fprintf(logfile , "service type: %d\n",(unsigned int)iph->tos);
    fprintf(logfile , "proto: %d\n",(unsigned int)iph->protocol);
    fprintf(logfile , "cksum: %d\n",ntohs(iph->check));
    fprintf(logfile , "source ip: %s\n" , inet_ntoa(source.sin_addr) );
    fprintf(logfile , "destination ip: %s\n" , inet_ntoa(dest.sin_addr) );
    fprintf(logfile , "len: %d  Bytes(Size of Packet)\n",ntohs(iph->tot_len));
}
void tcp_print(const u_char * Buffer, int Size)
{
    unsigned short len_iph;
    struct iphdr *iph = (struct iphdr *)( Buffer  + sizeof(struct ethhdr) );
    len_iph = iph->ihl*4;
    struct tcphdr *tcph=(struct tcphdr*)(Buffer + len_iph + sizeof(struct ethhdr));
    int header_size =  sizeof(struct ethhdr) + len_iph + tcph->doff*4;
    fprintf(logfile , "\npacket-tcp\n");  
    print_ip_header(Buffer,Size);
    fprintf(logfile , "\n");
    fprintf(logfile , "header-tcp\n");
    fprintf(logfile , "source port %u\n",ntohs(tcph->source));
    fprintf(logfile , "dest port : %u\n",ntohs(tcph->dest));
    fprintf(logfile , "seq no.: %u\n",ntohl(tcph->seq));
    fprintf(logfile , "ack no.: %u\n",ntohl(tcph->ack_seq));
    fprintf(logfile , "len: %d DWORDS or %d BYTES\n" ,(unsigned int)tcph->doff,(unsigned int)tcph->doff*4);
    fprintf(logfile , "window size: %d\n",ntohs(tcph->window));
    fprintf(logfile , "chksum: %d\n",ntohs(tcph->check));
    fprintf(logfile , "\n");
    fprintf(logfile , "header-ip\n");
    data_print(Buffer,len_iph);
    fprintf(logfile , "header-tcp\n");
    data_print(Buffer+len_iph,tcph->doff*4);
    fprintf(logfile , "payload\n");    
  	if(svalue != NULL) {
     if(strstr(Buffer + header_size,svalue) != NULL){
    data_print(Buffer + header_size , (Size - header_size) );
     }
	}
	else {
    data_print(Buffer + header_size , (Size - header_size) );
	}
    fprintf(logfile , "\n");
}
void udp_print(const u_char *Buffer , int Size)
{
    unsigned short len_iph;
    struct udphdr *udph = (struct udphdr*)(Buffer + len_iph  + sizeof(struct ethhdr));
    struct iphdr *iph = (struct iphdr *)(Buffer +  sizeof(struct ethhdr));
    len_iph = iph->ihl*4;
    int header_size =  sizeof(struct ethhdr) + len_iph + sizeof udph;
    fprintf(logfile , "\n\npacket-udp\n");
    print_ip_header(Buffer,Size);           
    fprintf(logfile , "\nheader\n");
    fprintf(logfile , "src port: %d\n" , ntohs(udph->source));
    fprintf(logfile , "dest port: %d\n" , ntohs(udph->dest));
    fprintf(logfile , "len: %d\n" , ntohs(udph->len));
    fprintf(logfile , "Chcksum: %d\n" , ntohs(udph->check));
    fprintf(logfile , "\n");
    fprintf(logfile , "header-ip\n");
    data_print(Buffer , len_iph);
    fprintf(logfile , "header-udp\n");
    data_print(Buffer+len_iph , sizeof udph);
    fprintf(logfile , "payload\n");    
    	if(svalue != NULL) {
     if(strstr(Buffer + header_size,svalue) != NULL){
    data_print(Buffer + header_size , (Size - header_size) );
     }
	}
	else {
    data_print(Buffer + header_size , (Size - header_size) );
	}
    fprintf(logfile , "\n");
}
void icmp_print(const u_char * Buffer , int Size)
{
    unsigned short len_iph;
    struct iphdr *iph = (struct iphdr *)(Buffer  + sizeof(struct ethhdr));
    len_iph = iph->ihl * 4;
    struct icmphdr *icmph = (struct icmphdr *)(Buffer + len_iph  + sizeof(struct ethhdr));
    int header_size =  sizeof(struct ethhdr) + len_iph + sizeof icmph;
    fprintf(logfile , "\n\npacket-icmp\n"); 
    print_ip_header(Buffer , Size);
    fprintf(logfile , "\n");
    fprintf(logfile , "header-icmp\n");
    fprintf(logfile , "type: %d",(unsigned int)(icmph->type));
    fprintf(logfile , "code: %d\n",(unsigned int)(icmph->code));
    fprintf(logfile , "checksum: %d\n",ntohs(icmph->checksum));
    fprintf(logfile , "\n");
    fprintf(logfile , "header-ip\n");
    data_print(Buffer,len_iph);
    fprintf(logfile , "header-udp\n");
    data_print(Buffer + len_iph , sizeof icmph);
    fprintf(logfile , "payload\n");    

	if(svalue != NULL) {
     if(strstr(Buffer + header_size,svalue) != NULL){
    data_print(Buffer + header_size , (Size - header_size) );
     }
	}
	else {
    data_print(Buffer + header_size , (Size - header_size) );
	}
    fprintf(logfile , "\n");
}
void data_print (const u_char * data , int Size)
{
    int p1 , p2;
    for(p1=0 ; p1 < Size ; p1++)
    {
        if( p1!=0 && p1%16==0)  
        {
            fprintf(logfile , "         ");
            for(p2=p1-16 ; p2<p1 ; p2++)
            {
                if(data[p2]>=32 && data[p2]<=128)
                    fprintf(logfile , "%c",(unsigned char)data[p2]); 
                 
                else fprintf(logfile , "."); 
            }
            fprintf(logfile , "\n");
        } 
         
        if(p1%16==0) fprintf(logfile , "   ");
            fprintf(logfile , " %02X",(unsigned int)data[p1]);
        if( p1==Size-1)  
        {
            for(p2=0;p2<15-p1%16;p2++) 
            {
              fprintf(logfile , "   "); 
            }
             
            fprintf(logfile , "         ");
             
            for(p2=p1-p1%16 ; p2<=p1 ; p2++)
            {
                if(data[p2]>=32 && data[p2]<=128) 
                {
                  fprintf(logfile , "%c",(unsigned char)data[p2]);
                }
                else
                {
                  fprintf(logfile , ".");
                }
            }
             
            fprintf(logfile ,  "\n" );
        }
    }
}
