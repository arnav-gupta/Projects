  import java.util.Date;
  import java.lang.*;
  
import org.jnetpcap.*;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.*;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Tcp;
import org.jnetpcap.util.PcapPacketArrayList;
import org.jnetpcap.protocol.tcpip.*;
  
  
      
      
  public class MyPcapB {
    
    String FileAddress = "";
    static int mssi = 0;
    static long sequ = 0;
    static int threway = 0;
    static int inLen = 0;
    static int goodLen = 0;
    static int cnt = 0;
    static long inTime = 0;
    static long afTime = 0;
    static boolean flag = false;
    private static Object Http;
    
    
    public MyPcapB(String FileAddress)
    {
      this.FileAddress = FileAddress;
    }
    
    public static void main(String[] args) {  
  	  
      
        final String FILENAME = "HTTP_SampleA.pcap";  
        final StringBuilder errbuf = new StringBuilder();  


        final Pcap pcap = Pcap.openOffline(FILENAME, errbuf);  
        if (pcap == null)   
            System.err.println(errbuf);  
              
          PcapPacketHandler<PcapPacketArrayList> jpacketHandler = new PcapPacketHandler<PcapPacketArrayList>() {  
          
              public void nextPacket(PcapPacket packet, PcapPacketArrayList PaketsList) {  
    
                  PaketsList.add(packet);
              }  
          };
          try {  
            PcapPacketArrayList packets = new PcapPacketArrayList();
            pcap.loop(-1,jpacketHandler,packets);
           
            for(int i=0; i<packets.size();i++){
            	//System.out .println("packet count:"+i);
            	PcapPacket packet = packets.get(i);
            			Tcp tcp = new Tcp();
            			Ip4 ip = new Ip4();
            			Http hp = new Http();
            			byte[] sIP = new byte[4];
            			byte[] dIP = new byte[4];
            			String sourceIP="";
            			String destIP="";
            			
            		
            			if (packet.hasHeader(hp)) {
            				Http h = packet.getHeader(hp);
            				String s = new String(h.getHeader());
            				//System.out.println("Header====="+ s);
            				}
            			
            			if (packet.hasHeader(tcp)) {
            		cnt++;		
            			
            		if(!flag || (mssi==0) ){
            		for (JHeader subheader : tcp.getSubHeaders()) {
            			
            			if (subheader instanceof Tcp.NoOp) continue;
            			 else if (subheader instanceof Tcp.MSS) {
            				// System.out.println ("IBAroda");
            			Tcp.MSS mss = (Tcp.MSS) subheader;
            			mssi = mss.mss();
            			flag = true;
            			 }
            			else if (subheader instanceof Tcp.WindowScale) continue;
            			 else if (subheader instanceof Tcp.Timestamp) continue;
            			 else if (subheader instanceof Tcp.TcpOption) continue;
            			
            			
            			
            		}
            		}
            		
            		
            					  JBuffer buffer = packet;
             			  int size = packet.getTotalSize();
             			  //byte[] array = buffer.getByteArray(0, size);
             			  
             			  inLen = inLen + packet.getPacketWirelen();
             			 goodLen = goodLen + packet.getPacketWirelen();
            			if(cnt == 1) inTime = packet.getCaptureHeader().timestampInMicros();
            			else afTime = packet.getCaptureHeader().timestampInMicros();
            			
            			if(tcp.flags_PSH()) goodLen = inLen - packet.getPacketWirelen();
            			 
            				/*
            				if(tcp.flags_SYN()){
            				threway =1;	
            				}
            				else if(tcp.flags_ACK() && tcp.flags_SYN()){
            				
            					if(threway == 1) threway =2;
            					else  {
            						threway =0;
            						continue;
            					}
            					
            				}
            				else if(tcp.flags_ACK()){
            					if(threway == 2) threway =3;
            					else {
            						threway =0;
            						continue;
            					}
            				}
            				
            			}*/
            			
            			/*
            			if(packet.hasHeader(tcp)){
            				
            			   JBuffer buffer = packet;
            			   if(sequ == tcp.seq()) continue;
            			   int size = packet.size();
            			   byte[] array = buffer.getByteArray(0, size);  
            			   System.out.println("Sequence number: " + buffer.getUInt(4));
            			   sequ = tcp.seq();
            			   System.out.println("sequence value otherwise:" + tcp.seq());
            			   System.out.println("Acknowledge number: " + buffer.getUInt(8));
            			   //sequ = tcp.ack();
            			   System.out.println("acknowledge value otherwise:" + tcp.ack());
            			   System.out.println("Window number: " + buffer.getUShort(14));
            			   //sequ = tcp.ack();
            			   System.out.println("Window value otherwise:" + tcp.window());
            			   
            			   
            			   sIP = packet.getHeader(ip).source();
            			   sourceIP = org.jnetpcap.packet.format.FormatUtils.ip(sIP);
            			   dIP = packet.getHeader(ip).destination();
            			   destIP = org.jnetpcap.packet.format.FormatUtils.ip(dIP);
            			   System.out.println("*"+sourceIP+"*"+destIP);
            			   System.out.println("Source IP"+ sourceIP);
            			   System.out.println("Destination IP"+ destIP);
            			   if(tcp.source()==80)
            			      System.out.println("HTTP protocol");
            			   else if(tcp.source()==23)
            			      System.out.println("Telnet protocol");
            			   //System.out.println("Packet Information: "+ packet.toString());

            			}*/
            }
            }
            //System.out.println("inLen =" + inLen);
            //System.out.println("inTime =" + inTime);
            //System.out.println("afTime =" + afTime);
            float dif = (float) ((afTime-inTime)/(Math.pow(10, 6)));
            //System.out.println("afTime =" + dif);
            float throughput = (inLen/dif); 
            System.out.println("through put = " + throughput);
            float goodput = (goodLen/dif);
            System.out.println("good put = " + goodput);
            
            int rcnt = cnt -1;
            //System.out.println("rcnt =" + rcnt);
            float rtt = (dif/rcnt)*2;
            System.out.println("average RTT = " + rtt);
            System.out.println("initial congestion window: " + mssi);
            // return packets;
          
          }
            finally {  
             //Last thing to do is close the pcap handle 
             pcap.close();  
          } 
          
          
          
        
    }      
  }
    
    
  