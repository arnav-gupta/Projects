  import java.util.Date;
  
  import org.jnetpcap.*;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.*;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Tcp;
import org.jnetpcap.util.PcapPacketArrayList;
import org.jnetpcap.protocol.tcpip.*;
  
  
      
      
  public class MyPcapA {

    String FileAddress = "";
    static long sequ = 0;
	private static Object Http;
    
    /**
     * 
     * @param FileAddress  Address and the name of the PCAP file.
     */
    public MyPcapA(String FileAddress)
    {
      this.FileAddress = FileAddress;
    }
    
    public static void main(String[] args) {  
  	  
        /* 
         * Example #1 open offline capture file for reading packets. 
         */  
        final String FILENAME = "http_first_sample.pcap";  
        final StringBuilder errbuf = new StringBuilder();  


        final Pcap pcap = Pcap.openOffline(FILENAME, errbuf);  
        if (pcap == null)   
            System.err.println(errbuf); // Error is stored in errbuf if any  
              
      PcapPacketHandler<PcapPacketArrayList> jpacketHandler = new PcapPacketHandler<PcapPacketArrayList>() {  
          
              public void nextPacket(PcapPacket packet, PcapPacketArrayList PaketsList) {  
    
                  PaketsList.add(packet);
              }  
          };
          
          try {  
            PcapPacketArrayList packets = new PcapPacketArrayList();
            pcap.loop(-1,jpacketHandler,packets);
           
            for(int i=0; i<packets.size();i++){
            	
            	PcapPacket packet = packets.get(i);
            			Tcp tcp = new Tcp();
            			Ip4 ip = new Ip4();
            			Http hp = new Http();
            			byte[] sIP = new byte[4];
            			byte[] dIP = new byte[4];
            			String sourceIP="";
            			String destIP="";
            			/*
            			if (packet.hasHeader(hp)) {
            				Http h = packet.getHeader(hp);
            				String s = new String(h.getHeader());
            				System.out.println("Header====="+ s);
            				}
            			*/
            			
            			if(packet.hasHeader(tcp) ){
            				System.out .println("packet count:"+i);			
            			   JBuffer buffer = packet;
            			   if(sequ == tcp.seq()) continue;
            			   int size = packet.size();
            			   byte[] array = buffer.getByteArray(0, size);  
            			  // System.out.println("Sequence number: " + buffer.getUInt(4));
            			//   sequ = tcp.seq();
            			   System.out.println("sequence value otherwise:" + tcp.seq());
            			   //System.out.println("Acknowledge number: " + buffer.getUInt(8));
            			   //sequ = tcp.ack();
            			   System.out.println("acknowledge value otherwise:" + tcp.ack());
            			   //System.out.println("Window number: " + buffer.getUShort(14));
            			   //sequ = tcp.ack();
            			   System.out.println("Window value otherwise:" + tcp.window());
               			/*
            			   if (packet.hasHeader(hp)) {

               			Http h = packet.getHeader(hp);
            				String s = new String(h.getHeader());
            				System.out.println("Header====="+ s);
            				}*/
            			   
            			   /*
            			   sIP = packet.getHeader(ip).source();
            			   sourceIP = org.jnetpcap.packet.format.FormatUtils.ip(sIP);
            			   dIP = packet.getHeader(ip).destination();
            			   destIP = org.jnetpcap.packet.format.FormatUtils.ip(dIP);
            			   System.out.println("*"+sourceIP+"*"+destIP);
            			   System.out.println("Source IP"+ sourceIP);
            			   System.out.println("Destination IP"+ destIP);
            			   if(tcp.source()==80)
            			      System.out.println("HTTP protocol");
            			   else if(tcp.source()==23)
            			      System.out.println("Telnet protocol");
            			   //System.out.println("Packet Information: "+ packet.toString());
*/
            			}
            }
            
          // return packets;
          } finally {  
             //Last thing to do is close the pcap handle 
             pcap.close();  
          } 
          
          
    }      
  }
    
    
  