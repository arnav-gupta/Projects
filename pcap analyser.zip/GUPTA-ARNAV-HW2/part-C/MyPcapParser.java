  import java.util.Date;
  import java.lang.*;
  
import org.jnetpcap.*;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.*;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Tcp;
import org.jnetpcap.util.PcapPacketArrayList;
import org.jnetpcap.protocol.tcpip.*;
      
  public class MyPcapParser {
    
    String FileAddress = "";
    static int mssi = 0;
    static long sequ = 0;
    static int inLen = 0;
    static int goodLen = 0;
    static int cnt = 0;
    static int rtocount = 0;
    static float srtt =1;
    static float rttvar;
    static float [] rto = new float [3];
    static long inTime = 0;
    static long afTime = 0;
    static long acklen = 0;
    static long congwin = 0;
    static long packlen = 0;
    static long minack = 0;
    static boolean flag = false;
    private static Object Http;
		
    
    public MyPcapParser(String FileAddress)
    {
      this.FileAddress = FileAddress;
    }
    
    public static void main(String[] args) {  
  	  
      
        final String FILENAME = "HTTP_Sample_Big_Packet.pcap";  
        final StringBuilder errbuf = new StringBuilder();  


        final Pcap pcap = Pcap.openOffline(FILENAME, errbuf);  
        if (pcap == null)   
            System.err.println(errbuf); // Error is stored in errbuf if any  
              
             PcapPacketHandler<PcapPacketArrayList> jpacketHandler = new PcapPacketHandler<PcapPacketArrayList>() {  
          
              public void nextPacket(PcapPacket packet, PcapPacketArrayList PaketsList) {  
    
                  PaketsList.add(packet);
              }  
          };
          try {  
            PcapPacketArrayList packets = new PcapPacketArrayList();
            pcap.loop(-1,jpacketHandler,packets);
             for(int i=10; i<packets.size();i++){
            	//System.out .println("packet count:"+i);
            	PcapPacket packet = packets.get(i);
            			Tcp tcp = new Tcp();
            			Ip4 ip = new Ip4();
            			byte[] sIP = new byte[4];
            			byte[] dIP = new byte[4];
            			String sourceIP="";
            			String destIP="";
            			
            			byte[] dsIP = new byte[4];
            			byte[] ddIP = new byte[4];
            			String dsourceIP="";
            			String ddestIP="";

            			if(packet.hasHeader(tcp)){
                            sIP = packet.getHeader(ip).source();
            			   sourceIP = org.jnetpcap.packet.format.FormatUtils.ip(sIP);
            			   dIP = packet.getHeader(ip).destination();
            			   destIP = org.jnetpcap.packet.format.FormatUtils.ip(dIP);
            		
            			   if(sourceIP.equals("128.208.2.180")){
                			   JBuffer buffer = packet;
            				   int size = packet.size();
                			   byte[] array = buffer.getByteArray(0, size);
                			    packlen = tcp.seq();
                			   congwin = congwin+packlen;
                			   if(congwin<minack) minack = congwin;
            			}
            			   if(sourceIP.equals("128.208.4.212")){
                			   JBuffer buffer = packet;
            				   int size = packet.size();
                			   byte[] array = buffer.getByteArray(0, size);
                			    acklen = tcp.ack();
                			   long cwin = packlen - acklen;
                			   if ((cnt%2)==0) 
                			   System.out.println("Congestion Window Size=  " + cwin);
                			   inTime = packet.getCaptureHeader().timestampInMicros();
                			   //System.out.println("inTime= " + inTime);
                			   cnt++;
                			   
                	             for(int j=0; j<i;j++){
                	             	
                	             	PcapPacket packeta = packets.get(j);
                	             			Tcp tcpa = new Tcp();
                	             			if(packeta.hasHeader(tcpa)){
                	             				if(tcpa.seq() == acklen) {
                	             				
                	             					afTime = packeta.getCaptureHeader().timestampInMicros();
                	             					//System.out.println("afTime= " + afTime);
                	             					float dif = (float) ((inTime-afTime)/(Math.pow(10, 6)));
                	             					if ((cnt%2)==0)
                	             					System.out.println("RTT = " + dif);
                	             		            rtocount++;
                	             		            
                	             		            if(rtocount<=3){
                	             		            	if(rtocount ==1){
                	             		            		srtt = dif;
                	             		            		rttvar = dif/2;
                	             		            		rto[0] = (srtt + Math.max(1,(4*rttvar)));
                	             		            		System.out.println("Re-transmission time out= " + rto[0]);
                	             		            	}
                	             		            	else {
                	             		            		rttvar = ((1-(1/4))*rttvar +(1/4) * Math.abs((srtt-dif)));
                	             		            		srtt = ((1-(1/8))*srtt + (1/8)*dif);
                	             		            		rto[rtocount-1] = srtt + Math.max(1, (4*rttvar));
                	             		            		System.out.println("Re-transmission time out= " + rto[rtocount-1]);
                	             		            	}
                	             		            	
                	             		            }
                	             		            
                	             				}
                	             			}

                	             }
                			   
                			   if(cnt == 40) System.exit(0);
                			   
                			  
            			   }
            }			           				   
         }
          }
            finally {  
             //Last thing to do is close the pcap handle 
             pcap.close();  
          } 
    }
  }
          