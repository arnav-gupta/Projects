external Librarires used:

Jnetpcap


Design

This code uses the jnetpcap library feature to analyse the binary pcap file in bytes and then access the different attributes of the tcp and http packets to do the analysis for various question.

In Part-A

Question 1: I have found out the http connection packets and for ech of this packets I have found the sequence no, acknowledgement number and window size.
I have also displayed this using  diagream the http flow.

Questio 2: In this answers I have explained the significance of sequence no, acnowledgement number and 
window size for the 3 transaction after the initial three way connection si setup.


In Part-B

Question-1 
In question 1 I have explained which kind of Http connection is being used in both the Pcap files. Here the Http 1.1 persistent connection is being used.


Question-2

Here throughput is the total amount of bytes transferred per flow over time and goodput is the total amount of useful byte transferred per flow over time. Goodput does not consider retransmissions

Average RTT is the average over the complete tcp connection between one source and destination.

Initial congestion window is the size of 1 MSS which is equal to 1460 bytes.




Part-C

Question-1

In question 1 I have claculated the congestion window and the rtt for the first 20 rtt based on the server side and I have drawn the graph for the same in the excel file.

Qustion-2

In the question-2 I have calculated the re-transmission time out based on the RTT of the server for the first three transactions after the initail three way handshake is done. 
The RTO formula is based ont the RFC 6298.





How to run the program

part A

javac MyPcapA.java
java MyPcapA


part B

javac MyPcapB
java MyPcapB

javac MyPcapBB
java MyPcapBB


part C

javac MyPcapParser
java MyPcapParser

