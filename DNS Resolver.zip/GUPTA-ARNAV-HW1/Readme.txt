external Librarires used:

dnsjava(org.xbill.DNS)


Design

This code is an implmentation of the recursive dns resolver.
The dns query are resolved in a recursive manner.
First the query is sent to the root server to find the address of tld servers.
Here a round-robin algorithm is applied wherein the 13 root server are stored in a arraylist and one by one the query is made to each of the root server. As soon as one of the root server gives the address of the tld server, this address is used to find Name server secondary tlds.
The secondary tlds are then queried for the ip address of the website.
Thus the discovery of each level is done iteratively starting from the root server to the actual ip address of the domain.



How to run the program

part A

javac ExampleOne.java
java ExampleOne www.google.com.


part B

javac DigCode.java
java DigCode www.google.com. A


part C

javac TimeCal.java
java TimeCal www.google.com. A

javac DigPublic.java
java DigPublic www.google.com. A



