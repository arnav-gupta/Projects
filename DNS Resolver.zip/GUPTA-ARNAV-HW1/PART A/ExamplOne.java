import org.xbill.DNS.*;
import java.lang.*;
import java.util.*;
import java.net.UnknownHostException;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.io.*;


/**
 */
class ExampleOne
{
  public static void main(String[] args) throws ClassCastException,RelativeNameException,UnknownHostException, TextParseException, IOException
  {
	try{  
	  long t1= System.currentTimeMillis();
    ArrayList <String> RuServer= roundRobin();
	  int flag =1;
    for ( int kn=0; kn<RuServer.size() && flag!=0;kn++){
    	String RootServer = RuServer.get(kn);
	
    String dnsblDomain = args[0];
    Name n = Name.fromString(dnsblDomain);
    int cnt= n.labels();
    
    int nscnt = cnt-2;
    ArrayList <NSRecord> arr= new ArrayList<NSRecord>();
    
    Record [] r = findNS(RootServer,dnsblDomain);
    if(r==null)break;
    for (int j = 0; j < r.length; j++)
    {
  	  arr.add((NSRecord) r[j]);
    }
  
    for (int i=1;i<nscnt;i++){
    	Record [] re=null;
    	for ( int k=0; k<arr.size();k++){
    		String nsServer= arr.get(k).getTarget().toString();
    		re = findNS(nsServer,dnsblDomain);
    		if(re!=null) break;
    	}
    	arr.clear();
    	for (int j = 0; j < re.length; j++)
        {
      	  arr.add((NSRecord) re[j]);
        }
    	
    }
    
	for ( int k=0; k<arr.size();k++){
		String nsServer= arr.get(k).getTarget().toString();
		//System.out.println("nsServer=  " + nsServer);
		Record [] rel = findA(nsServer,dnsblDomain);
				
		if(rel!=null) {
			flag=1;
			long t2= System.currentTimeMillis();
			System.out.println("Website = "+args[0]);
			//System.out.println("Time= "+(t2-t1));
			System.exit(0);
			
		}
	}
    }
    
  }
    catch(ClassCastException e){
		
		  System.out.println("Invalid Input");
		
	  }
  }
  
  public static Record[] findNS (String RServer, String dnsDomain) throws RelativeNameException,UnknownHostException, TextParseException, IOException
  {
 	    String tldR=""; 
 	    SimpleResolver sr = new SimpleResolver(RServer);
 	    Message msg = Message.newQuery(Record.newRecord(new Name(dnsDomain), Type.NS, DClass.IN, Section.AUTHORITY));
 	    Message response = sr.send(msg);
 //	    System.out.println(" response = " + response.toString());
 	    return response.getSectionArray(2);	  
 	  
   }
  
  public static Record[] findA (String RServer, String dnsDomain) throws RelativeNameException,UnknownHostException, TextParseException, IOException
  {
 	    SimpleResolver sr = new SimpleResolver(RServer);
 	    Message msg = Message.newQuery(ARecord.newRecord(new Name(dnsDomain), Type.A, DClass.IN, Section.AUTHORITY));
 	    Message response = sr.send(msg);
 	    Record rb1[]=response.getSectionArray(1);
 		for(int i=0; i<rb1.length; i++)
 		System.out.println("IP Address="+rb1[i].rdataToString());
 	    return response.getSectionArray(2);	  
 	  
   }
  
  public static ArrayList<String> roundRobin(){
	ArrayList <String> ar2=new ArrayList<String>();
	ar2.add("198.41.0.4");
	ar2.add("192.228.79.201");
	ar2.add("192.33.4.12");
	ar2.add("199.7.91.13");
	ar2.add("192.203.230.10");
	ar2.add("192.5.5.241");
	ar2.add("192.112.36.4");
	ar2.add("198.97.190.53");
	ar2.add("192.36.148.17");
	ar2.add("192.58.128.30");
	ar2.add("193.0.14.129");
	ar2.add("199.7.83.42");
	ar2.add("202.12.27.33");
	
	  return ar2;
  }
  
}
